#include <iostream>
#include "fractions.h"
#include <cstdlib>
#include <time.h>

using namespace std;

// // // // // // // // // // // // // // // // // // //
// Author: Kyle Reinholt                              //
//                                                    //
// Program: Operator Overload Exercise w/Fractions    //
//                                                    //
// Usage: Follow directions prompted and input values //
//                                                    //
// Class: CS 240 MWF 9-9:50                           //
// // // // // // // // // // // // // // // // // // //

int main()
{
    srand(time(NULL));

    int testsPassed = 0; // Counter for all tests passed
    int testsFailed = 0; // "                   " failed
    int randNegNum = 0; // Variable for negative numbers test
    int randInt = 0;
    int userNumerator = 0; // This is how the user will answer the problems
    int userDenominator = 0;  // "                                          "
    int userInput = 0;
    int correctAnswers = 0;
    int wrongAnswers = 0;
    int n = 0;//numerator
    int d = 0;//denominator
    int numOfProblems = 0; // Variable for cin statement that asks user how many problems they want to do
    bool validInput = 0;
    bool trueOrFalse = 0; // This is for testing purposes, Its a pass or fail flag
    bool flag = 0;
    bool returnToMenu = true;

    //EVERYTHING ABOVE THE WHILE LOOP BELONGS TO THE TESTING SUITE
    /*
    for(int i = 1; i < 11; i++) //Test to verify generation of negative numbers between -1 to -100
    {
        randNegNum = generateRandNegNum();
        trueOrFalse = numRangeChecker(randNegNum); // numRangeChecker(int) verifies that the parameter is between (-101,0) and (0,101)

        cout << "tests: " << i << " = " << randNegNum << endl;
                                                   // and returns true or false
        if( trueOrFalse == true )
        {
            testsPassed++;
        }
        else
        {
            testsFailed++;
        }
    }

    for(int j = 1; j < 11; j++) //Test to verify generation of neg or pos integers from -100 to -1 and 1 to 100
    {
        randInt = randomizeNegToPos();
        trueOrFalse = numRangeChecker(randInt); // refer to line 21

        cout << "Int " << j << " = " << randInt << endl;

        if( trueOrFalse == true )
        {
            testsPassed++;
        }
        else
        {
            testsFailed++;
        }
    }

    printTestResults(testsPassed,testsFailed);

    n = randomizeNegToPos();
    d = randomizeNegToPos();

    cout << "n = " << n << endl;
    cout << "d = " << d << endl;

    Fraction myFraction;
    myFraction.setFraction(n,d);

    cout << "getnumerator = " << myFraction.getNumerator() << endl;
    cout << "getdenominator = " << myFraction.getDenominator() << endl;
    //myFraction(n,d);

    n = randomizeNegToPos();
    d = randomizeNegToPos();

    cout << "n = " << n << endl;
    cout << "d = " << d << endl;

    Fraction yourFraction;
    yourFraction.setFraction(n,d);

    cout << yourFraction << " + " << myFraction << endl;

    Fraction example = myFraction + yourFraction;
    /*cout << yourFraction << " + " << myFraction << " = " << endl;
    cout << "Type the answer for the numerator: ";
    cin >> userNumerator;
    cout << "Type the answer for the denominator: ";
    cin >> userDenominator;
    cout << "Here is your answer: " << userNumerator << " / " << userDenominator << endl;

    n = randomizeNegToPos();
    d = randomizeNegToPos();

    myFraction.setFraction(n,d);

    cout << "getnumerator = " << myFraction.getNumerator() << endl;
    cout << "getdenominator = " << myFraction.getDenominator() << endl;
    //myFraction(n,d);

    n = randomizeNegToPos();
    d = randomizeNegToPos();

    cout << "n = " << n << endl;
    cout << "d = " << d << endl;

    yourFraction.setFraction(n,d);

    cout << myFraction << " - " << yourFraction << endl;

    example = myFraction - yourFraction;
    cout << myFraction << " - " << yourFraction << " = " << example << endl;

    example = myFraction * yourFraction;
    cout << myFraction << " * " << yourFraction << " = " << example << endl;

    myFraction++;
    cout << myFraction << " post-increment ++" << endl;

    ++myFraction;
    cout << myFraction << " pre-increment++" << endl;

    --myFraction;
    cout << myFraction << " pre-increment--" << endl;

    myFraction--;
    cout << myFraction << " post-increment--" << endl;



    myFraction.setFraction(n,d);
    yourFraction.setFraction(n,d);

    example = myFraction / yourFraction;

    cout << myFraction << " / " << yourFraction << " = " << example << endl;

    */

    /*
    myFraction.setFraction(1,2);
    yourFraction.setFraction(1,2);

    yourFraction--;
    cout << yourFraction << endl;

    --yourFraction;
    cout << yourFraction << endl;

    if(myFraction == yourFraction)
    {
        cout << true << endl;
    }
    else
    {
        cout << false << endl;
    }

    if(myFraction!=yourFraction)
    {
        cout << true << endl;
    }
    else
    {
        cout << false << endl;
    }


    if(myFraction < yourFraction)
    {
        cout << true << endl;
    }
    else
    {
        cout << false << endl;
    }

    if(myFraction > yourFraction)
    {
        cout << true << endl;
    }
    else
    {
        cout << false << endl;
    }

    if(myFraction >= yourFraction)
    {
        cout << true << endl;
    }
    else
    {
        cout << false << endl;
    }

    if(myFraction <= yourFraction)
    {
        cout << true << endl;
    }
    else
    {
        cout << false << endl;
    }*/

    Fraction myFraction;
    Fraction yourFraction;

    while(returnToMenu == true)
    {
        userMenu(); //Displays the menu.. should I change this?"
        cout << "Enter [100] to quit. " << endl;
        cin >> userInput;

        if(userInput == 100)
        {
            returnToMenu = false;
        }
        else
        {
            validInput = verifyUserInput(userInput);

            if( validInput == true )
            {
                numOfProblems = chooseNumOfProblems();

                if( numOfProblems > 20 || numOfProblems < 1 )
                {
                    flag = 0;

                    while(flag == 0)
                    {
                        numOfProblems = chooseNumOfProblems();

                        if( numOfProblems > 20 || numOfProblems < 1 )
                        {
                            flag = 0;
                        }

                        else
                        {
                            flag = 1;
                        }

                    }

                    cout << "You will now attempt " << numOfProblems << " " << typeOfProblem(userInput) << " problem(s)." << endl;

                    switch(userInput)
                    {
                    case 1:
                        for(int i = 0; i < numOfProblems;i++)
                        {
                            n = randomizeNegToPos();
                            d = randomizeNegToPos();

                            myFraction.setFraction(n,d);

                            n = randomizeNegToPos();
                            d = randomizeNegToPos();

                            yourFraction.setFraction(n,d);

                            Fraction example = myFraction + yourFraction;

                            cout << "Problem: " << i+1 << endl;
                            cout << yourFraction << " + " << myFraction << " = " << endl;

                            cout << "Type the answer for the numerator: ";
                            cin >> userNumerator;

                            cout << "Type the answer for the denominator: ";
                            cin >> userDenominator;

                            cout << "Here is your answer: " << userNumerator << " / " << userDenominator << endl;
                            cout << "Here is the correct answer: " << example << endl;

                            if(userNumerator == example.getNumerator() && userDenominator == example.getDenominator())
                            {
                                correctAnswers = correctAnswers++;
                            }
                            else
                            {
                                wrongAnswers = wrongAnswers++;
                            }
                        }
                        break;

                    case 2:
                        for(int j = 0; j < numOfProblems;j++)
                        {
                            n = randomizeNegToPos();
                            d = randomizeNegToPos();

                            myFraction.setFraction(n,d);

                            n = randomizeNegToPos();
                            d = randomizeNegToPos();

                            yourFraction.setFraction(n,d);

                            Fraction example = myFraction - yourFraction;

                            cout << "Problem: " << j+1 << endl;
                            cout << myFraction << " - " << yourFraction << " = " << endl;

                            cout << "Type the answer for the numerator: ";
                            cin >> userNumerator;

                            cout << "Type the answer for the denominator: ";
                            cin >> userDenominator;

                            cout << "Here is your answer: " << userNumerator << " / " << userDenominator << endl;
                            cout << "Here is the correct answer: " << example << endl;

                            if(userNumerator == example.getNumerator() && userDenominator == example.getDenominator())
                            {
                                correctAnswers = correctAnswers++;
                            }
                            else
                            {
                                wrongAnswers = wrongAnswers++;
                            }
                        }
                        break;

                    case 3:
                        for(int k = 0; k < numOfProblems;k++)
                        {
                            n = randomizeNegToPos();
                            d = randomizeNegToPos();

                            myFraction.setFraction(n,d);

                            n = randomizeNegToPos();
                            d = randomizeNegToPos();

                            yourFraction.setFraction(n,d);

                            Fraction example = myFraction * yourFraction;

                            cout << "Problem: " << k+1 << endl;
                            cout << myFraction << " * " << yourFraction << " = " << endl;

                            cout << "Type the answer for the numerator: ";
                            cin >> userNumerator;

                            cout << "Type the answer for the denominator: ";
                            cin >> userDenominator;

                            cout << "Here is your answer: " << userNumerator << " / " << userDenominator << endl;
                            cout << "Here is the correct answer: " << example << endl;

                            if( userNumerator == example.getNumerator() && userDenominator == example.getDenominator() )
                            {
                                correctAnswers = correctAnswers++;
                            }
                            else
                            {
                                wrongAnswers = wrongAnswers++;
                            }
                        }
                        break;

                    case 4:
                        for(int l = 0; l < numOfProblems;l++)
                        {
                            n = randomizeNegToPos();
                            d = randomizeNegToPos();

                            myFraction.setFraction(n,d);

                            n = randomizeNegToPos();
                            d = randomizeNegToPos();

                            yourFraction.setFraction(n,d);

                            Fraction example = myFraction / yourFraction;

                            cout << "Problem: " << l+1 << endl;
                            cout << myFraction << " / " << yourFraction << " = " << endl;

                            cout << "Type the answer for the numerator: ";
                            cin >> userNumerator;

                            cout << "Type the answer for the denominator: ";
                            cin >> userDenominator;

                            cout << "Here is your answer: " << userNumerator << " / " << userDenominator << endl;
                            cout << "Here is the correct answer: " << example << endl;

                            if(userNumerator == example.getNumerator() && userDenominator == example.getDenominator())
                            {
                                correctAnswers = correctAnswers++;
                            }
                            else
                            {
                                wrongAnswers = wrongAnswers++;
                            }
                        }
                        break;
                    }


                }

                else if( numOfProblems < 21 && numOfProblems > 0 )
                {
                    cout << "You will now attempt " << numOfProblems << " " << typeOfProblem(userInput) << " problem(s)." << endl;

                    switch(userInput)
                    {
                    case 1:
                        for(int i = 0; i < numOfProblems;i++)
                        {
                            n = randomizeNegToPos();
                            d = randomizeNegToPos();

                            myFraction.setFraction(n,d);

                            n = randomizeNegToPos();
                            d = randomizeNegToPos();

                            yourFraction.setFraction(n,d);

                            Fraction example = myFraction + yourFraction;

                            cout << "Problem: " << i+1 << endl;
                            cout << yourFraction << " + " << myFraction << " = " << endl;

                            cout << "Type the answer for the numerator: ";
                            cin >> userNumerator;

                            cout << "Type the answer for the denominator: ";
                            cin >> userDenominator;

                            cout << "Here is your answer: " << userNumerator << " / " << userDenominator << endl;
                            cout << "Here is the correct answer: " << example << endl;

                            if(userNumerator == example.getNumerator() && userDenominator == example.getDenominator())
                            {
                                correctAnswers = correctAnswers++;
                            }
                            else
                            {
                                wrongAnswers = wrongAnswers++;
                            }
                        }
                        break;

                    case 2:
                        for(int j = 0; j < numOfProblems;j++)
                        {
                            n = randomizeNegToPos();
                            d = randomizeNegToPos();

                            myFraction.setFraction(n,d);

                            n = randomizeNegToPos();
                            d = randomizeNegToPos();

                            yourFraction.setFraction(n,d);

                            Fraction example = myFraction - yourFraction;

                            cout << "Problem: " << j+1 << endl;
                            cout << myFraction << " - " << yourFraction << " = " << endl;

                            cout << "Type the answer for the numerator: ";
                            cin >> userNumerator;

                            cout << "Type the answer for the denominator: ";
                            cin >> userDenominator;

                            cout << "Here is your answer: " << userNumerator << " / " << userDenominator << endl;
                            cout << "Here is the correct answer: " << example << endl;

                            if(userNumerator == example.getNumerator() && userDenominator == example.getDenominator())
                            {
                                correctAnswers = correctAnswers++;
                            }
                            else
                            {
                                wrongAnswers = wrongAnswers++;
                            }
                        }
                        break;

                    case 3:
                        for(int k = 0; k < numOfProblems;k++)
                        {
                            n = randomizeNegToPos();
                            d = randomizeNegToPos();

                            myFraction.setFraction(n,d);

                            n = randomizeNegToPos();
                            d = randomizeNegToPos();

                            yourFraction.setFraction(n,d);

                            Fraction example = myFraction * yourFraction;

                            cout << "Problem: " << k+1 << endl;
                            cout << myFraction << " * " << yourFraction << " = " << endl;

                            cout << "Type the answer for the numerator: ";
                            cin >> userNumerator;

                            cout << "Type the answer for the denominator: ";
                            cin >> userDenominator;

                            cout << "Here is your answer: " << userNumerator << " / " << userDenominator << endl;
                            cout << "Here is the correct answer: " << example << endl;

                            if( userNumerator == example.getNumerator() && userDenominator == example.getDenominator() )
                            {
                                correctAnswers = correctAnswers++;
                            }
                            else
                            {
                                wrongAnswers = wrongAnswers++;
                            }
                        }
                        break;

                    case 4:
                        for(int l = 0; l < numOfProblems;l++)
                        {
                            n = randomizeNegToPos();
                            d = randomizeNegToPos();

                            myFraction.setFraction(n,d);

                            n = randomizeNegToPos();
                            d = randomizeNegToPos();

                            yourFraction.setFraction(n,d);

                            Fraction example = myFraction / yourFraction;

                            cout << "Problem: " << l+1 << endl;
                            cout << myFraction << " / " << yourFraction << " = " << endl;


                            cout << "Type the answer for the numerator: ";
                            cin >> userNumerator;

                            cout << "Type the answer for the denominator: ";
                            cin >> userDenominator;

                            cout << "Here is your answer: " << userNumerator << " / " << userDenominator << endl;
                            cout << "Here is the correct answer: " << example << endl;

                            if(userNumerator == example.getNumerator() && userDenominator == example.getDenominator())
                            {
                                correctAnswers = correctAnswers++;
                            }
                            else
                            {
                                wrongAnswers = wrongAnswers++;
                            }
                        }
                        break;
                    }
                }

                else
                {
                    cout << "ERROR" << endl;
                    returnToMenu;
                }

            }

            else if( validInput == false )
            {
                cout << "Invalid Input" << endl;
                cin.clear();
                cin.ignore(10000,'\n');
                returnToMenu;
            }

            else
            {
                cout << "ERROR" << endl;
                returnToMenu;
            }
        }
    }

    cout << endl << "You attempted a total of: " << correctAnswers + wrongAnswers << " problem(s)." << endl;
    cout << endl << "You answered " << correctAnswers << " problem(s) correctly." << endl;
    cout << "You answered " << wrongAnswers << " problem(s) incorrectly." << endl;

    return 0;
}
