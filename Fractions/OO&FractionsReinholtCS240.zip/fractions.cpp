#include <iostream>
#include "fractions.h"
#include <cstdlib>

int generateRandNegNum() // Generates a negative integer from -100 to -1
{
    int negRandNum = 0;

    negRandNum = ((rand() % 100 + 1) * -1);

    return negRandNum;
}

int randomizeNegToPos() // Takes a negative number, flips a coin: tails - it stays negative,
{                       // heads - it converts it to a positive
    bool tails = false;
    bool heads = true;
    int randomInt = 0;
    int flipOfCoin = 0;

    flipOfCoin = rand() % 2;

        if( flipOfCoin == tails )
        {
            randomInt = generateRandNegNum();
        }
        else if( flipOfCoin == heads )
        {
            randomInt = ((generateRandNegNum()) * -1);
        }
        else
        {
            cout << "ERROR" << endl;
        }

    return randomInt;
}

int numRangeChecker(int randomNum)
{
    bool testPassed = 0;

        if(randomNum >= -100 && randomNum <= 100)
        {
            testPassed = true;
        }
        else
        {
            testPassed = false;
        }

    return testPassed;
}

void printTestResults(int passed, int failed)
{
    cout << endl << "Tests Passed: " << passed << endl;
    cout << "Tests Failed: " << failed << endl;
}

void userMenu()
{
    cout << "Please choose a problem type from below." << endl;

    cout << "1. Addition " << endl;
    cout << "2. Subtraction " << endl;
    cout << "3. Multiplication " << endl;
    cout << "4. Division " << endl;
}

string typeOfProblem(int userInput)
{
    string problemType =" ";

    switch(userInput)
    {
    case 1:
        problemType = "Addition";
        break;
    case 2:
        problemType = "Subtraction";
        break;
    case 3:
        problemType = "Multiplication";
        break;
    case 4:
        problemType = "Division";
        break;
    default:
        cout << "ERROR" << endl;
        break;
    }

    return problemType;
}

bool verifyUserInput(int userInput)
{
    bool validInput = 0;

    if(userInput > 0 && userInput < 5)
    {
        validInput = true;
    }
    else if(cin.fail()==true)
    {
        validInput = false;
    }
    else
    {
        validInput = false;
    }

    return validInput;
}

int chooseNumOfProblems()
{
    int userInput = 0;

    cout << "How many problems would you like attempt? (1-20) " << endl;
    cin >> userInput;

    return userInput;
}

void Fraction::setFraction(int n, int d)
{
    if(d < 0)
    {
        denominator = d * -1;
        numerator = n;
    }
    else
    {
        numerator = n;
        denominator = d;
    }
}

int Fraction::getNumerator() const
{
    return numerator;
}

int Fraction::getDenominator() const
{
    return denominator;
}

void Fraction::print() const
{
    cout << numerator << "/" << denominator << endl;
}

Fraction::Fraction(int n, int d)
{
    if(d < 0)
    {
        d = d * -1;
    }
    else
    {
        setFraction(n,d);
    }

}

Fraction::Fraction()
{
    numerator = 0;
    denominator = 0;
}

Fraction Fraction::operator+(const Fraction& fraction) const
{
    Fraction temp;

    int tempDnmntr = 0;
    int tempNmrtr = 0;
    int fractionTempNmrtr = 0;
    int fractionTempDnmntr = 0;

    const int fractionNPlusPlus = fraction.numerator;
    const int fractionDPlusPlus = fraction.denominator;
    const int dPlusPlus = denominator;
    const int nPlusPlus = numerator;

    tempDnmntr = denominator;
    tempNmrtr = numerator;
    fractionTempNmrtr = fraction.numerator;
    fractionTempDnmntr = fraction.denominator;

    while(tempDnmntr != fractionTempDnmntr)
    {
        if (tempDnmntr < fractionTempDnmntr)
        {
            tempDnmntr = tempDnmntr + dPlusPlus;
            tempNmrtr = tempNmrtr + nPlusPlus;
        }
        else if(tempDnmntr > fractionTempDnmntr)
        {
            fractionTempDnmntr = fractionDPlusPlus + fractionTempDnmntr;
            fractionTempNmrtr = fractionNPlusPlus + fractionTempNmrtr;
        }
        else
        {
            cout << "ERROR" << endl;
        }
    }

    temp.numerator = tempNmrtr + fractionTempNmrtr;
    temp.denominator = fractionTempDnmntr;

    return temp;
}

Fraction Fraction::operator-(const Fraction& fraction) const
{
    Fraction temp;

    int tempDnmntr = 0;
    int tempNmrtr = 0;
    int fractionTempNmrtr = 0;
    int fractionTempDnmntr = 0;

    const int fractionNPlusPlus = fraction.numerator;
    const int fractionDPlusPlus = fraction.denominator;
    const int dPlusPlus = denominator;
    const int nPlusPlus = numerator;

    tempDnmntr = denominator;
    tempNmrtr = numerator;
    fractionTempNmrtr = fraction.numerator;
    fractionTempDnmntr = fraction.denominator;

    while(tempDnmntr != fractionTempDnmntr)
    {
        if (tempDnmntr < fractionTempDnmntr)
        {
            tempDnmntr = tempDnmntr + dPlusPlus;
            tempNmrtr = tempNmrtr + nPlusPlus;
        }
        else if(tempDnmntr > fractionTempDnmntr)
        {
            fractionTempDnmntr = fractionDPlusPlus + fractionTempDnmntr;
            fractionTempNmrtr = fractionNPlusPlus + fractionTempNmrtr;
        }
        else
        {
            cout << "ERROR" << endl;
        }
    }

    temp.numerator = (tempNmrtr) - (fractionTempNmrtr);
    temp.denominator = fractionTempDnmntr;

    return temp;
}

Fraction Fraction::operator*(const Fraction& fraction) const
{
    Fraction temp;

    temp.numerator = this -> numerator * fraction.numerator;
    temp.denominator = this -> denominator * fraction.denominator;

    return temp;
}

Fraction Fraction::operator/(const Fraction& fraction) const
{
    Fraction temp;

    temp.numerator = this -> numerator * fraction.denominator;
    temp.denominator = this -> denominator * fraction.numerator;

    return temp;
}

//pre-increment ++something
Fraction Fraction::operator++()
{
    numerator = numerator + denominator;

    return *this;
}

//post-increment something++
Fraction Fraction::operator++(int)
{
    Fraction temp = *this;

    numerator = numerator + denominator;

    return temp;
}

Fraction Fraction::operator--()
{
    numerator = numerator - denominator;

    return *this;
}

Fraction Fraction::operator--(int)
{
    Fraction temp = *this;

    numerator = numerator - denominator;

    return temp;
}

ostream& operator << (ostream& osObject, const Fraction& fraction)
{
    osObject << fraction.numerator << "/" << fraction.denominator;

    return osObject;
}

istream& operator >> (istream& isObject, Fraction& fraction)
{
    isObject >> fraction.numerator >> fraction.denominator;

    return isObject;

}

bool operator==(const Fraction& fractionA, const Fraction& fractionB)
{
    bool flag = 0;

    if(fractionA.getDenominator() == fractionB.getDenominator() && fractionA.getNumerator() == fractionB.getNumerator())
    {
        flag = 1;
    }
    else
    {
        flag = 0;
    }

    return flag;
}

bool operator!=(const Fraction& fractionA, const Fraction& fractionB)
{
    bool flag = 0;

    int fractionAValue = fractionA.getNumerator()/fractionA.getDenominator();
    int fractionBValue = fractionB.getNumerator()/fractionB.getDenominator();

    if(fractionAValue != fractionBValue)
    {
        flag = 1;
    }
    else
    {
        flag = 0;
    }

    return flag;
}

bool operator<(const Fraction& fractionA, const Fraction& fractionB)
{
    bool flag = 0;

    int fractionAValue = fractionA.getNumerator()/fractionA.getDenominator();
    int fractionBValue = fractionB.getNumerator()/fractionB.getDenominator();

    if( fractionAValue < fractionBValue )
    {
        flag = 1;
    }
    else
    {
        flag = 0;
    }

    return flag;
}

bool operator>(const Fraction& fractionA, const Fraction& fractionB)
{
    bool flag = 0;

    int fractionAValue = fractionA.getNumerator()/fractionA.getDenominator();
    int fractionBValue = fractionB.getNumerator()/fractionB.getDenominator();

    if( fractionAValue > fractionBValue )
    {
        flag = 1;
    }
    else
    {
        flag = 0;
    }

    return flag;
}

bool operator<=(const Fraction& fractionA, const Fraction& fractionB)
{
    bool flag = 0;

    int fractionAValue = fractionA.getNumerator()/fractionA.getDenominator();
    int fractionBValue = fractionB.getNumerator()/fractionB.getDenominator();

    if( fractionAValue < fractionBValue || fractionAValue == fractionBValue )
    {
        flag = 1;
    }
    else
    {
        flag = 0;
    }

    return flag;
}

bool operator>=(const Fraction& fractionA, const Fraction& fractionB)
{
    bool flag = 0;

    int fractionAValue = fractionA.getNumerator()/fractionA.getDenominator();
    int fractionBValue = fractionB.getNumerator()/fractionB.getDenominator();

    if( fractionAValue > fractionBValue || fractionAValue == fractionBValue )
    {
        flag = 1;
    }
    else
    {
        flag = 0;
    }

    return flag;
}
